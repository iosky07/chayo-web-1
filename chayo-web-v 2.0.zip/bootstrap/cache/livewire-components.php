<?php return array (
  'create-user' => 'App\\Http\\Livewire\\CreateUser',
  'custom-modal' => 'App\\Http\\Livewire\\CustomModal',
  'customer-form' => 'App\\Http\\Livewire\\CustomerForm',
  'invoice-form' => 'App\\Http\\Livewire\\InvoiceForm',
  'log-form' => 'App\\Http\\Livewire\\LogForm',
  'packet-tag-form' => 'App\\Http\\Livewire\\PacketTagForm',
  'payment-form' => 'App\\Http\\Livewire\\PaymentForm',
  'sales-form' => 'App\\Http\\Livewire\\SalesForm',
  'table.main' => 'App\\Http\\Livewire\\Table\\Main',
);