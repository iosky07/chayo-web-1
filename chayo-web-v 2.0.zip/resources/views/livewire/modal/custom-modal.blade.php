<div>
    <livewire:custom-modal :wire:key="'custom-modal-'.time()">

</div>
