<div>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.data-table','data' => ['data' => $data,'model' => $customers]]); ?>
<?php $component->withName('data-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data),'model' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($customers)]); ?>


         <?php $__env->slot('head', null, []); ?> 
            <tr>
                <th><a wire:click.prevent="sortBy('id')" role="button" href="#">
                        ID
                        <?php echo $__env->make('components.sort-icon', ['field' => 'id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </a></th>
                <th><a wire:click.prevent="sortBy('name')" role="button" href="#">
                        Nama
                        <?php echo $__env->make('components.sort-icon', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </a></th>
                <th><a wire:click.prevent="sortBy('created_at')" role="button" href="#">
                        Status
                        <?php echo $__env->make('components.sort-icon', ['field' => 'created_at'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </a></th>
                <th><a wire:click.prevent="sortBy('address')" role="button" href="#">
                        Alamat
                        <?php echo $__env->make('components.sort-icon', ['field' => 'address'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </a></th>
                <th><a wire:click.prevent="sortBy('location_picture')" role="button" href="#">
                        Tagihan
                        <?php echo $__env->make('components.sort-icon', ['field' => 'location_picture'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </a></th>



                <th>Action</th>

                <th>Pembayaran</th>
            </tr>
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('body', null, []); ?> 
            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr x-data="window.__controller.dataTableController(<?php echo e($m->id); ?>)">
                    <td><?php echo e($m->id); ?></td>
                    <td><?php echo e($m->name); ?></td>
                    <td>
                        <?php if($m->status == 'paid'): ?>
                            <div class="badge badge-success">Lunas</div>
                        <?php elseif($m->status == 'unpaid'): ?>
                                <div class="badge badge-warning">Belum Lunas</div>
                        <?php elseif($m->status == 'suspend'): ?>
                            <div class="badge badge-dark">Suspended</div>
                        <?php elseif($m->status == 'isolate'): ?>
                            <div class="badge badge-danger">Isolir</div>
                        <?php endif; ?>
                    </td>
                    
                    
                    <td><?php echo e($m->address); ?></td>
                    <td>


                        <?php if($m->total_bill  == 0): ?>
                            -
                        <?php elseif($m->total_bill > 0): ?>
                            Rp. <?php echo e(number_format($m->total_bill, 0, ',', '.')); ?> (<?php echo e(ceil($m->total_bill/$m->bill)); ?>)
                        <?php endif; ?>

                    <td>
                        <ul class="navbar-nav navbar-right">
                            <li class="dropdown"><a href="#" data-turbolinks="false" data-toggle="dropdown" class="nav-link dropdown-toggle nav-link-lg nav-link-user">
                                    <div class="d-sm-none d-lg-inline-block"><i class="fa fa-16px fa-user"></i></div></a>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <a href="<?php echo e(route('admin.customer_detail', $m->id)); ?>" class="dropdown-item has-icon" target="_blank"><i class="fa fa-16px fa-user"> </i> Detail Pelanggan</a>
                                    <a href="https://wa.me/<?php echo e('62'.substr($m->phone_number, 1)); ?>" class="dropdown-item has-icon" target="_blank"><i class="fa fa-16px fa-phone"> </i> Whatsapp</a>
                                    <a href="https://maps.google.com/?q=<?php echo e($m->longitude); ?>,<?php echo e($m->latitude); ?>" class="dropdown-item has-icon" target="_blank"><i class="fa fa-16px fa-map-marked"> </i> Lokasi</a>
                                    <a href="<?php echo e(route('admin.customer.edit', $m->id)); ?>" class="dropdown-item has-icon"><i class="fa fa-16px fa-pen"></i> Edit</a>
                                    <a x-on:click.prevent="deleteItem" href="#" class="dropdown-item has-icon"><i class="fa fa-16px fa-trash"></i> Hapus</a>
                                    <?php if($m->status == 'isolate'): ?>
                                        <a href="#" class="bg-danger dropdown-item has-icon"><b><?php echo e(\Carbon\Carbon::now()->diff(\Carbon\Carbon::parse($m->isolate_date))->format('%m')); ?> Bulan <?php echo e(\Carbon\Carbon::now()->diff(\Carbon\Carbon::parse($m->isolate_date))->format('%d')); ?> Hari <?php echo e(\Carbon\Carbon::now()->diff(\Carbon\Carbon::parse($m->isolate_date))->format('%h')); ?> Jam</b></a>
                                    <?php endif; ?>
                                </div>
                            </li>
                        </ul>
                    </td>
                    <td>
                        <?php if($m->status == 'suspend'): ?>
                            <a class="btn btn-success trigger--fire-modal-5 disabled" href="<?php echo e(route('admin.index_with_id', $m->id)); ?>">Invoice</a>
                            <a class="btn btn-primary trigger--fire-modal-5 disabled" href="<?php echo e(route('admin.payment_index_with_id', $m->id)); ?>">Bayar</a>
                            <a x-on:click.prevent="customerSuspend" class="btn btn-danger trigger--fire-modal-5 disabled" href="#">Isolir</a>
                            <a x-on:click.prevent="customerSuspend" class="btn btn-dark trigger--fire-modal-5" href="#">Unsuspend</a>
                        <?php else: ?>
                            <a class="btn btn-success trigger--fire-modal-5" href="<?php echo e(route('admin.index_with_id', $m->id)); ?>">Invoice</a>
                            <a class="btn btn-primary trigger--fire-modal-5" href="<?php echo e(route('admin.payment_index_with_id', $m->id)); ?>">Bayar</a>
                            <a x-on:click.prevent="customerSuspend" class="btn btn-danger trigger--fire-modal-5" href="#">Isolir</a>
                            <a x-on:click.prevent="customerSuspend" class="btn btn-outline-dark trigger--fire-modal-5" href="#">Suspend</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\chayo-web-1\resources\views/livewire/table/customer.blade.php ENDPATH**/ ?>