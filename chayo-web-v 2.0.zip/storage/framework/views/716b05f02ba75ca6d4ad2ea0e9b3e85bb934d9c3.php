<?php $attributes = $attributes->exceptProps(['on', 'message', 'type']); ?>
<?php foreach (array_filter((['on', 'message', 'type']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div x-data="{ message: '<?php echo e($message); ?>', 'type': '<?php echo e($type); ?>' }"
    x-init="window.livewire.find('<?php echo e($_instance->id); ?>').on('<?php echo e($on); ?>', () => { console.log('fired 2'); const notyf = new Notyf({ position: { x: 'center', 'y': 'button' } }); notyf[type](message); })">
</div>
<?php /**PATH C:\xampp\htdocs\chayo-web-1\resources\views/components/notify-message.blade.php ENDPATH**/ ?>