






<a href="/">
    <img class="w-20 h-25" fill="none" src=<?php echo e("template-assets/assets/img/chayo/main-logo.png"); ?> alt="" class="img-fluid">
</a>
<?php /**PATH C:\xampp\htdocs\chayo-web-1\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>