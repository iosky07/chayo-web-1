<div class="form-group col-span-6 sm:col-span-5">
    <label for="<?php echo e($title); ?>"><?php echo e($title); ?></label>
    <input type="<?php echo e($type); ?>" class="mt-1 block w-full form-control shadow-none" wire:model.defer="<?php echo e($model); ?>"/>
    <?php $__errorArgs = [$model];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-700"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH C:\xampp\htdocs\chayo-web-1\resources\views/components/form/input.blade.php ENDPATH**/ ?>