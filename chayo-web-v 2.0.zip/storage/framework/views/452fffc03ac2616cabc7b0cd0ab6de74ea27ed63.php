<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header_content', null, []); ?> 
        <h1><?php echo e(__('Data Pelanggan Sales')); ?></h1>

        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></div>
            <div class="breadcrumb-item"><a href="#">Pelanggan</a></div>
            <div class="breadcrumb-item"><a href="<?php echo e(route('admin.sales.index')); ?>">Data Pelanggan Sales</a></div>
        </div>
     <?php $__env->endSlot(); ?>

    <div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('table.main', ['name' => 'sale','model' => $sales])->html();
} elseif ($_instance->childHasBeenRendered('Pp0pL5t')) {
    $componentId = $_instance->getRenderedChildComponentId('Pp0pL5t');
    $componentTag = $_instance->getRenderedChildComponentTagName('Pp0pL5t');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Pp0pL5t');
} else {
    $response = \Livewire\Livewire::mount('table.main', ['name' => 'sale','model' => $sales]);
    $html = $response->html();
    $_instance->logRenderedChild('Pp0pL5t', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\chayo-web-1\resources\views/pages/sales/index.blade.php ENDPATH**/ ?>