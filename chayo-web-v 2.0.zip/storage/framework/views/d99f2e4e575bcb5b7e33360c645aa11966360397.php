<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header_content', null, []); ?> 
        <h1><?php echo e(__('Tambah Pembayaran Baru')); ?></h1>

        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></div>
            <div class="breadcrumb-item"><a href="#">Pembayaran</a></div>
            <div class="breadcrumb-item"><a href="<?php echo e(route('admin.payment_index_with_id', $id)); ?>">Tambah Pembayaran Baru</a></div>
        </div>
     <?php $__env->endSlot(); ?>

    <div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-form', ['action' => 'create'])->html();
} elseif ($_instance->childHasBeenRendered('GZ6w9iv')) {
    $componentId = $_instance->getRenderedChildComponentId('GZ6w9iv');
    $componentTag = $_instance->getRenderedChildComponentTagName('GZ6w9iv');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('GZ6w9iv');
} else {
    $response = \Livewire\Livewire::mount('payment-form', ['action' => 'create']);
    $html = $response->html();
    $_instance->logRenderedChild('GZ6w9iv', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\chayo-web-1\resources\views/pages/payment/create.blade.php ENDPATH**/ ?>