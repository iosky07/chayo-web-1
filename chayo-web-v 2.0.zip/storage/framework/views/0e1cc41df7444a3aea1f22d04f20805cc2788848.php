<div>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.data-table','data' => ['data' => $data,'model' => $sale]]); ?>
<?php $component->withName('data-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data),'model' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sale)]); ?>


         <?php $__env->slot('head', null, []); ?> 
            <tr>
                <th><a wire:click.prevent="sortBy('id')" role="button" href="#">
                        ID
                        <?php echo $__env->make('components.sort-icon', ['field' => 'id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </a></th>
                <th><a wire:click.prevent="sortBy('name')" role="button" href="#">
                        Nama
                        <?php echo $__env->make('components.sort-icon', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </a></th>
                <th><a wire:click.prevent="sortBy('created_at')" role="button" href="#">
                        Status
                        <?php echo $__env->make('components.sort-icon', ['field' => 'created_at'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </a></th>
                <th><a wire:click.prevent="sortBy('address')" role="button" href="#">
                        Alamat
                        <?php echo $__env->make('components.sort-icon', ['field' => 'address'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </a></th>
                <th><a wire:click.prevent="sortBy('identity_picture')" role="button" href="#">
                        Foto KTP
                        <?php echo $__env->make('components.sort-icon', ['field' => 'identity_picture'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </a></th>



                <th>Action</th>

                <th>Pembayaran</th>
            </tr>
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('body', null, []); ?> 

            <?php $__currentLoopData = $sale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr x-data="window.__controller.dataTableController(<?php echo e($s->id); ?>)">
                    <td><?php echo e($s->id); ?></td>
                    <td><?php echo e($s->name); ?></td>
                    <td>
                        <?php if($s->status == 'prospect'): ?>
                            <div class="badge badge-success">Proses</div>
                        <?php elseif($s->status == 'decline'): ?>
                            <div class="badge badge-danger">Gagal</div>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($s->address); ?></td>
                    <td>
                        <img src="<?php echo e(asset('storage/img/identity_picture/'.$s->identity_picture)); ?>" alt="" style="width: 200px">
                    <td>
                        <ul class="navbar-nav navbar-right">
                            <li class="dropdown"><a href="#" data-turbolinks="false" data-toggle="dropdown" class="nav-link dropdown-toggle nav-link-lg nav-link-user">
                                    <div class="d-sm-none d-lg-inline-block"><i class="fa fa-16px fa-user"></i></div></a>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <a href="<?php echo e(route('admin.customer_detail', $s->id)); ?>" class="dropdown-item has-icon" target="_blank"><i class="fa fa-16px fa-user"> </i> Detail Pelanggan</a>
                                    <a href="https://wa.me/<?php echo e('62'.substr($s->phone_number, 1)); ?>" class="dropdown-item has-icon" target="_blank"><i class="fa fa-16px fa-phone"> </i> Whatsapp</a>
                                    <a href="https://maps.google.com/?q=<?php echo e($s->longitude); ?>,<?php echo e($s->latitude); ?>" class="dropdown-item has-icon" target="_blank"><i class="fa fa-16px fa-map-marked"> </i> Lokasi</a>
                                    <a href="<?php echo e(route('admin.sales.edit', $s->id)); ?>" class="dropdown-item has-icon"><i class="fa fa-16px fa-pen"></i> Edit</a>
                                    <a x-on:click.prevent="deleteItem" href="#" class="dropdown-item has-icon"><i class="fa fa-16px fa-trash"></i> Hapus</a>
                                    <?php if($s->status == 'isolate'): ?>
                                        <a href="#" class="bg-danger dropdown-item has-icon"><b><?php echo e(\Carbon\Carbon::now()->diff(\Carbon\Carbon::parse($s->isolate_date))->format('%m')); ?> Bulan <?php echo e(\Carbon\Carbon::now()->diff(\Carbon\Carbon::parse($s->isolate_date))->format('%d')); ?> Hari <?php echo e(\Carbon\Carbon::now()->diff(\Carbon\Carbon::parse($s->isolate_date))->format('%h')); ?> Jam</b></a>
                                    <?php endif; ?>
                                </div>
                            </li>
                        </ul>
                    </td>
                    <td>
                        <?php if($s->status == 'suspend'): ?>
                            <a x-on:click.prevent="salesDecline" class="btn btn-danger trigger--fire-modal-5 disabled" href="#">Tolak</a>
                            <a x-on:click.prevent="salesAccept" class="btn btn-success trigger--fire-modal-5" href="#">Terima</a>
                        <?php else: ?>
                            <a x-on:click.prevent="salesDecline" class="btn btn-danger trigger--fire-modal-5" href="#">Tolak</a>
                            <a x-on:click.prevent="salesAccept" class="btn btn-success trigger--fire-modal-5" href="#">Terima</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\chayo-web-1\resources\views/livewire/table/sales.blade.php ENDPATH**/ ?>