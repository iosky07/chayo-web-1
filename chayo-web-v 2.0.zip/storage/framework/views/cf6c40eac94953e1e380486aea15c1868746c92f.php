<div>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.data-table','data' => ['data' => $data,'model' => $invoices]]); ?>
<?php $component->withName('data-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data),'model' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($invoices)]); ?>
        <?php echo e($getId = intval(substr(url()->current(), -12))); ?>


         <?php $__env->slot('head', null, []); ?> 
            <tr>
                <th>Invoice ID</th>
                <th>Bulan</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('body', null, []); ?> 
                <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($i->customer_id == $getId): ?>
                        <tr x-data="window.__controller.dataTableController(<?php echo e($i->id); ?>)">
                            <td><?php echo e($i->id); ?></td>
                            <td>
                                <?php echo e(\Carbon\Carbon::parse($i->selected_date)->translatedFormat('F')); ?>

                            </td>
                            <td>
                                <?php if($i->status == 'paid'): ?>
                                    <div class="badge badge-success">Lunas</div>
                                <?php endif; ?>
                                <?php if($i->status == 'unpaid'): ?>
                                    <div class="badge badge-danger">Belum Dibayar</div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a role="button" href="<?php echo e(route('admin.generate_invoice', $i->id)); ?>" class="btn btn-success" target="_blank"><i class="fa fa-16px fa-print"></i> Cetak</a>
                                <a role="button" x-on:click.prevent="deleteItem" href="#" class="btn btn-danger"><i class="fa fa-16px fa-trash"></i> Hapus</a>
                            </td>
                        </tr>
                    <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\chayo-web-1\resources\views/livewire/table/invoice.blade.php ENDPATH**/ ?>