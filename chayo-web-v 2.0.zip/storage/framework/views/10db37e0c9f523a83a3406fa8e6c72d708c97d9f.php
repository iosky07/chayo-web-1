<div class="form-group col-span-6 sm:col-span-5">
    <label for="name"><?php echo e($title); ?></label>
    <select class="form-control" wire:model.defer="<?php echo e($model); ?>">

        <?php for($i=0;$i<count($options) ;$i++): ?>
            <option value="<?php echo e($options[$i]['value']); ?>" <?php echo e($isSelected($options[$i]['value']) ? 'selected="selected"' : ''); ?>>
                <?php echo e($options[$i]['title']); ?>

            </option>
        <?php endfor; ?>
        <?php $__errorArgs = [$model];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </select>
</div>
<?php /**PATH C:\xampp\htdocs\chayo-web-1\resources\views/components/form/select.blade.php ENDPATH**/ ?>