<div class="form-group col-span-6 sm:col-span-5" wire:ignore>
    <label for="<?php echo e($title); ?>"><?php echo e($title); ?></label>
    <div class="input-group">
        <div class="input-group-prepend">
            <div class="input-group-text">
                <i class="fas fa-calendar"></i>
            </div>
        </div>

        <input id="<?php echo e(str_replace(".", "", $model)); ?>" type="<?php echo e($type); ?>"
               class="form-control <?php echo e($type); ?>" wire:model.defer="<?php echo e($model); ?>" value="<?php echo e($model); ?>"/>
        <?php $__errorArgs = [$model];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <script>
        document.addEventListener('livewire:load', function () {

            $("#<?php echo e(str_replace(".", "", $model)); ?>").on("change.datetimepicker", () => {
                window.livewire.find('<?php echo e($_instance->id); ?>').set(
                    '<?php echo e($model); ?>',
                    $("#<?php echo e(str_replace(".", "", $model)); ?>").val()
                )
            });
        });
    </script>
</div>
<?php /**PATH C:\xampp\htdocs\chayo-web-1\resources\views/components/form/date.blade.php ENDPATH**/ ?>