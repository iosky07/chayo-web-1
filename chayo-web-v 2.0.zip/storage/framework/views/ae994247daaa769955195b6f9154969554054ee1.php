<div class="form-group col-span-6 sm:col-span-5">
    <label for="name"><?php echo e($title); ?></label>
    <div class="input-group">
        <div class="input-group-prepend">
            <div class="input-group-text">
                <i class="fas fa-calendar"></i>
            </div>
        </div>
        <input type="text" name="date" class="form-control <?php echo e(str_replace(".", "", $model)); ?>"
               id="<?php echo e(str_replace(".", "", $model)); ?>"
               wire:model.defer="<?php echo e($model); ?>">
    </div>
    <?php $__errorArgs = [$model];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <script>
        document.addEventListener('livewire:load', function () {
            $("#<?php echo e(str_replace(".", "", $model)); ?>").daterangepicker({
                    locale: {format: 'YYYY-MM-DD'},
                    drops: 'down',
                    opens: 'right',
                },
                function (start, end, label) {
                window.livewire.find('<?php echo e($_instance->id); ?>').set('<?php echo e($model); ?>', start.format('YYYY-MM-DD') + ' - ' + end.format('YYYY-MM-DD'))
                }
            )
        });
    </script>
</div><?php /**PATH C:\xampp\htdocs\chayo-web-1\resources\views/components/form/daterange.blade.php ENDPATH**/ ?>