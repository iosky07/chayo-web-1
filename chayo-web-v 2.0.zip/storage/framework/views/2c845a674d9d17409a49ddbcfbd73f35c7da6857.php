<div>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.data-table','data' => ['data' => $data,'model' => $payments]]); ?>
<?php $component->withName('data-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data),'model' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($payments)]); ?>
        <?php echo e($getId = intval(substr(url()->current(), -12))); ?>

         <?php $__env->slot('head', null, []); ?> 
            <tr>
                <th>Payment ID</th>
                <?php if($getId == 0): ?>
                    <th>Nama Customer</th>
                <?php endif; ?>
                <th>Bukti Transaksi</th>
                <th>Nominal</th>
                <th>Status</th>
                <th>Diajukan pada</th>
                <?php if($getId !== 0): ?>
                    <th>Disetujui pada</th>
                <?php endif; ?>

                <th>Action</th>
            </tr>
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('body', null, []); ?> 
            <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($getId !== 0): ?>
                    <?php if($p->customer_id == $getId): ?>
                        <tr x-data="window.__controller.dataTableController(<?php echo e($p->id); ?>)">
                            <td><?php echo e($p->id); ?></td>
                            <td>
                                <img src="<?php echo e(asset('storage/img/payment_picture/'.$p->payment_picture)); ?>" alt=""
                                     style="width: 100px">
                            </td>
                            <td>Rp. <?php echo e(number_format($p->nominal, 0, ',', '.')); ?></td>
                            <td>
                                <?php if($p->status == 'accept'): ?>
                                    <div class="badge badge-success">Diterima</div>
                                <?php elseif($p->status == 'decline'): ?>
                                    <div class="badge badge-danger">Ditolak</div>
                                <?php elseif($p->status == 'pending'): ?>
                                    <div class="badge badge-warning">Menunggu Persetujuan</div>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($p->created_at); ?></td>
                            <td>
                                <?php echo e($p->updated_at); ?>

                            </td>
                            <?php if($p->status == 'pending'): ?>
                                <td>
                                    <a disabled="yes" x-on:click.prevent="deleteItem" href="#" class="btn btn-danger"><i class="fa fa-16px fa-trash"></i> Hapus</a>
                                </td>
                            <?php elseif($p->status == 'accept'): ?>
                                <td>
                                    <a role="button" href="<?php echo e(route('admin.generate_payment', $p->id)); ?>" class="btn btn-success" target="_blank"><i class="fa fa-16px fa-print"></i> Cetak</a>
                                </td>
                            <?php else: ?>
                                <td>-</td>
                            <?php endif; ?>

                        </tr>
                    <?php endif; ?>
                <?php else: ?>
                    <?php if($p->status == 'pending'): ?>
                        <tr x-data="window.__controller.dataTableController(<?php echo e($p->id); ?>)">
                            <td><?php echo e($p->id); ?></td>
                            <td><?php echo e(\App\Models\Customer::whereId($p->customer_id)->value('name')); ?></td>
                            <td>
                                <img src="<?php echo e(asset('storage/img/payment_picture/'.$p->payment_picture)); ?>" alt="" style="width: 100px">
                            </td>
                            <td>Rp. <?php echo e(number_format($p->nominal, 0, ',', '.')); ?></td>
                            <td>
                                <?php if($p->status == 'accept'): ?>
                                    <div class="badge badge-success">Diterima</div>
                                <?php elseif($p->status == 'decline'): ?>
                                    <div class="badge badge-danger">Ditolak</div>
                                <?php elseif($p->status == 'pending'): ?>
                                    <div class="badge badge-warning">Menunggu Persetujuan</div>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($p->created_at); ?></td>
                            <td>
                                <a x-on:click.prevent="acceptPayment" href="#" class="btn btn-success"><i class="fa fa-16px fa-thumbs-up"></i> Terima</a>
                                <a x-on:click.prevent="declinePayment" href="#" class="btn btn-danger"><i class="fa fa-16px fa-thumbs-down"></i> Tolak</a>

                            </td>
                        </tr>
                    <?php endif; ?>
                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\chayo-web-1\resources\views/livewire/table/payment.blade.php ENDPATH**/ ?>