<div id="form-create" class=" card p-4">
    <form wire:submit.prevent="create">

        <?php if (isset($component)) { $__componentOriginal60144d6d166608191f2b34922d5f35a7ecda0b17 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\DateRange::class, ['title' => 'Pilih Tanggal','model' => 'invoice.selected_date']); ?>
<?php $component->withName('date-range'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'datetimepicker']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal60144d6d166608191f2b34922d5f35a7ecda0b17)): ?>
<?php $component = $__componentOriginal60144d6d166608191f2b34922d5f35a7ecda0b17; ?>
<?php unset($__componentOriginal60144d6d166608191f2b34922d5f35a7ecda0b17); ?>
<?php endif; ?>

        <div class="form-group col-span-6 sm:col-span-5"></div>
        <button type="submit" id="submit" class="btn btn-primary">Submit</button>

    </form>
</div>

<script>
    document.addEventListener('livewire:load', function () {
        window.livewire.on('redirect', () => {
            setTimeout(function () {
                window.location.href = "<?php echo e(route('admin.invoice.index')); ?>"; //will redirect to your blog page (an ex: blog.html)
            }, 2000); //will call the function after 2 secs.
        });
    });
</script>
<?php /**PATH C:\xampp\htdocs\chayo-web-1\resources\views/livewire/invoice-form.blade.php ENDPATH**/ ?>